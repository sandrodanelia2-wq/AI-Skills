# Logo Quality Checklist

Use this as a practical review, not as a box-ticking exercise. A serious weakness in a core category means the design needs another iteration.

## Identity and meaning
- [ ] The mark relates to the brand's purpose, character, or positioning.
- [ ] The concept is explainable in one or two clear sentences.
- [ ] The design avoids generic visual shorthand unless deliberately justified.
- [ ] It is not a close imitation of a known logo.

## Form and craft
- [ ] The silhouette is recognizable and visually balanced.
- [ ] Negative space and counters are intentional.
- [ ] Curves, corners, stroke weights, and joins are consistent.
- [ ] Wordmark kerning and spacing have been optically reviewed.
- [ ] No decorative detail exists without a reason.

## Function
- [ ] It works in solid black and solid white.
- [ ] It remains legible at small sizes relevant to the intended use.
- [ ] It works on both light and dark backgrounds.
- [ ] It does not depend on gradients, shadows, texture, or mockup effects.
- [ ] It can be reproduced in print and digital contexts.
- [ ] The symbol can stand alone only if it remains identifiable without the wordmark.

## Delivery
- [ ] SVG is valid, scalable, and editable where vector output is promised.
- [ ] Color values are documented.
- [ ] Primary and monochrome variants are included when requested.
- [ ] Clear-space and minimum-size guidance are practical.
- [ ] Font licensing and trademark clearance are not misrepresented.

## Quick stress tests
1. Reduce the logo to approximately 16–24 px and check whether its essential structure survives.
2. Remove all color and effects. Check the silhouette.
3. Place it on a plain light and plain dark background.
4. View the mark without its mockup or presentation context.
5. Ask whether a competitor in the same category could plausibly use the same mark. If yes, strengthen the concept.
