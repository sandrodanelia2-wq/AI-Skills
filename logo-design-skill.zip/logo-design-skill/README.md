# Logo Design Skill for Claude

A reusable Claude skill for designing, refining, critiquing, and packaging professional logo identities.

## Install

1. Upload `logo-design-skill.zip` to Claude's Skills interface, or extract this folder and upload the skill folder if the interface requests an unpacked skill.
2. Enable the **Logo Design** skill.
3. Ask Claude to design or critique a logo and provide any existing brand assets or constraints.

## Contents
- `SKILL.md` — workflow and behavior instructions
- `references/logo-quality-checklist.md` — quality and production review
- `templates/creative-brief.md` — optional brief template

The skill guides Claude's design process. Actual image generation and file export depend on the tools available in the Claude environment.
