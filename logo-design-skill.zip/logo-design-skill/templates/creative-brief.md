# Logo Creative Brief

## Brand
- Name:
- What it does:
- Audience:

## Positioning
- Brand essence:
- Personality (3–5 attributes):
- What should people feel or understand?

## Visual direction
- Preferred styles or references:
- Existing colors / typography:
- Motifs or styles to avoid:
- Competitors or adjacent brands to distinguish from:

## Applications
- Primary uses:
- Required logo variants:
- Smallest expected display size:
- Required file formats:

## Constraints and assumptions
- Must retain:
- Must not include:
- Open questions:
